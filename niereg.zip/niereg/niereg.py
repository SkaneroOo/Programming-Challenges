from random import randint
wl = [line.strip() for line in open("niereg.txt", 'r', encoding='utf-8')]
while True:
	rand=randint(0,len(wl)-1)
	niereg = [line.strip() for line in open(str(wl[rand])+".txt", 'r', encoding='utf-8')]
	print(wl[rand])
	while True:
		while True:
			while True:
				inp=input('Podstawowa forma >>>')
				if inp==niereg[0]:
					print('Dobrze')
					inp=''
					break
				else:
					inp=''
					print('Źle')
			inp=input('Druga forma >>>')
			if inp==niereg[1]:
				print('Dobrze')
				inp=''
				break
			else:
				inp=''
				print('Źle')
		inp=input('Trzecia forma >>>')
		if inp==niereg[2]:
			print('Dobrze')
			inp=''
			break
		else:
			inp=''
			print('Źle')
